from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater

from agents.website_builder_simple.agent import WebsiteBuilderSimple
from a2a.utils import (
    new_task,
    new_agent_text_message
)

from a2a.utils.errors import ServerError

from a2a.types import (
    Task,
    TaskState,
    UnsupportedOperationError
)

import asyncio

class WebsiteBuilderSimpleAgentExecutor(AgentExecutor):
    """
    實作 AgentExecutor 介面，將簡易網站建構代理整合至 A2A 框架中。
    Implements the AgentExecutor interface to integrate the
    website builder simple agent with the A2A framework.

    Mermaid 流程圖:
    ```mermaid
    sequenceDiagram
        participant Context as RequestContext
        participant Executor as WebsiteBuilderSimpleAgentExecutor
        participant Agent as WebsiteBuilderSimple
        participant Queue as EventQueue

        Executor->>Context: 獲取使用者輸入 (Get User Input)
        Executor->>Queue: 建立並加入任務 (Create & Enqueue Task)
        loop Invoke Agent
            Executor->>Agent: invoke(query)
            Agent-->>Executor: yield updates
            alt 任務未完成 (Task Incomplete)
                Executor->>Queue: 更新狀態: Working
            else 任務完成 (Task Complete)
                Executor->>Queue: 更新狀態: Completed
            end
        end
    ```
    """

    def __init__(self):
        self.agent = WebsiteBuilderSimple()

    async def execute(self, context: RequestContext, event_queue: EventQueue) -> None:
        """
        使用提供的上下文和事件佇列執行代理。
        Executes the agent with the provided context and event queue.
        """
        query = context.get_user_input()
        task = context.current_task
        if not task:
            task = new_task(context.message)
            await event_queue.enqueue_event(task)

        updater = TaskUpdater(event_queue, task.id, task.contextId)

        try:
            async for item in self.agent.invoke(query, task.contextId):
                is_task_complete = item.get("is_task_complete", False)

                if not is_task_complete:
                    message = item.get('updates','代理正在處理您的請求。 (The Agent is still working on your request.)')
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(message, task.contextId, task.id)
                    )
                else:
                    final_result = item.get('content','未收到結果 (no result received)')
                    await updater.update_status(
                        TaskState.completed,
                        new_agent_text_message(final_result, task.contextId, task.id)
                    )

                    await asyncio.sleep(0.1)  # 允許訊息處理的時間 (Allow time for the message to be processed)

                    break
        except Exception as e:
            error_message = f"發生錯誤 (An error occurred): {str(e)}"
            await updater.update_status(
                TaskState.failed,
                new_agent_text_message(error_message, task.contextId, task.id)
            )
            raise

    async def cancel(self, request: RequestContext, event_queue: EventQueue) -> Task | None:
        raise ServerError(error=UnsupportedOperationError())

"""
重點摘要:
- **核心概念**: 網站建構代理執行器 (Website Builder Agent Executor)。
- **關鍵技術**: 非同步任務執行, A2A 整合。
- **重要結論**: 處理從 A2A 伺服器接收到的請求，並調用 WebsiteBuilderSimple 代理來執行任務。
"""
