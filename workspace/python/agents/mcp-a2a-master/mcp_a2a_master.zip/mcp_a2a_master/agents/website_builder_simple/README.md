# 簡易網站建構代理 (Website Builder Simple Agent)

## 概覽

簡易網站建構代理 (Website Builder Simple Agent) 是一個專門的代理，顧名思義，負責建立簡單的網站。它接收來自 Host Agent 的指令，並利用其能力生成必要的 HTML、CSS 和 JavaScript 檔案，以建構基本的網站。

## 主要職責

*   **網站生成**：該代理的主要功能是根據 Host Agent 提供的規格，生成簡單網站的檔案和內容。
*   **A2A 通訊**：該代理使用 A2A 協定與 Host Agent 通訊，以接收任務並回傳工作結果。
*   **任務執行**：該代理執行 Host Agent 委派的任務。這可能涉及建立檔案、撰寫內容和建構網站結構。

## 如何執行

若要執行簡易網站建構代理，請從專案根目錄執行以下指令：

```bash
uv run python3 -m agents.website_builder_simple
```

## 與其他元件的互動

*   **Host Agent**：簡易網站建構代理從 Host Agent 接收任務，並回報其進度和結果。它在 Host Agent 的指導下運作。

```mermaid
graph TD
    Host[Host Agent] -->|委派任務 (Delegates Task)| Builder[Website Builder Agent]
    Builder -->|生成內容 (Generates Content)| Files[HTML/CSS/JS]
    Builder -->|回報結果 (Reports Result)| Host
```

---

## 重點摘要

- **核心概念**：
  <div style='text-align: left;'>
  - 專門負責生成網頁內容的 Worker Agent。
  - 封裝了網頁開發的專業知識 (Prompt Engineering)。
  </div>
- **關鍵技術**：
  <div style='text-align: left;'>
  - HTML5, CSS3, JavaScript 生成。
  - 單一檔案輸出 (Single-file output)。
  </div>
- **重要結論**：
  <div style='text-align: left;'>
  - 展示了如何建立一個專注於特定領域的 A2A 代理。
  - 透過 A2A 協定與 Host Agent 協作，實現複雜任務的子任務處理。
  </div>
- **行動項目**：
  <div style='text-align: left;'>
  - 觀察此 Agent 如何處理來自 Host Agent 的 Prompt 並生成程式碼。
  </div>
