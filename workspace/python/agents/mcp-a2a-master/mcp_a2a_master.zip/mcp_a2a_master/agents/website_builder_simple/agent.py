from collections.abc import AsyncIterable
from utilities.common.file_loader import load_instructions_file
from google.adk.agents import LlmAgent
from google.adk import Runner

from google.adk.artifacts import InMemoryArtifactService
from google.adk.sessions import InMemorySessionService
from google.adk.memory.in_memory_memory_service import InMemoryMemoryService

from google.genai import types

from rich import print as rprint
from rich.syntax import Syntax

import json
from typing import Any

from dotenv import load_dotenv
load_dotenv()

class WebsiteBuilderSimple:
    """
    一個簡易的網站建構代理，可以建立基本的網頁，並使用 Google 的代理開發框架構建。
    A simple website builder agent that can create basic web pages
    and is built using google's agent development framework.

    Mermaid 流程圖:
    ```mermaid
    sequenceDiagram
        participant Caller
        participant Builder as WebsiteBuilderSimple
        participant LlmAgent

        Caller->>Builder: invoke(query)
        Builder->>LlmAgent: run_async(query)
        loop Stream Events
            LlmAgent-->>Builder: Event
            Builder-->>Caller: {is_task_complete, content/updates}
        end
    ```
    """

    def __init__(self):
        self.system_instruction = load_instructions_file("agents/website_builder_simple/instructions.txt")
        self.description = load_instructions_file("agents/website_builder_simple/description.txt")
        self._agent = self._build_agent()
        self._user_id = "website_builder_simple_agent_user"
        self._runner = Runner(
            app_name=self._agent.name,
            agent=self._agent,
            artifact_service=InMemoryArtifactService(),
            session_service=InMemorySessionService(),
            memory_service=InMemoryMemoryService(),

        )

    def _build_agent(self) -> LlmAgent:
       return LlmAgent(
            name="website_builder_simple",
            model="gemini-2.5-flash",
            instruction=self.system_instruction,
            description=self.description,
        )

    async def invoke(self, query: str, session_id: str) -> AsyncIterable[dict]:
        """
        調用代理。
        隨著代理處理查詢，回傳更新串流給呼叫者。
        Invoke the agent
        Return a stream of updates back to the caller as the agent processes the query

        {
            'is_task_complete': bool,  # 指示任務是否完成 (Indicates if the task is complete)
            'updates': str,  # 任務進度更新 (Updates on the task progress)
            'content': str  # 如果完成，任務的最終結果 (Final result of the task if complete)
        }

        """

        session = await self._runner.session_service.get_session(
            app_name=self._agent.name,
            session_id=session_id,
            user_id=self._user_id,
        )

        if not session:
            session = await self._runner.session_service.create_session(
                app_name=self._agent.name,
                session_id=session_id,
                user_id=self._user_id,
            )

        user_content = types.Content(
            role="user",
            parts = [types.Part.from_text(text=query)]
        )

        async for event in self._runner.run_async(
            user_id=self._user_id,
            session_id=session_id,
            new_message=user_content
        ):
            print_json_response(event, "================ NEW EVENT ================")

            print(f"is_final_response: {event.is_final_response()}")

            if event.is_final_response():
                final_response = ""
                if event.content and event.content.parts and event.content.parts[-1].text:
                    final_response = event.content.parts[-1].text

                yield {
                    'is_task_complete': True,
                    'content': final_response
                }
            else:
                yield {
                    'is_task_complete': False,
                    'updates': "代理正在處理您的請求... (Agent is processing your request...)"
                }

def print_json_response(response: Any, title: str) -> None:
    # 顯示回應的格式化和顏色高亮視圖
    # Displays a formatted and color-highlighted view of the response
    print(f"\n=== {title} ===")  # 章節標題以便清晰 (Section title for clarity)
    try:
        if hasattr(response, "root"):  # 檢查回應是否被 SDK 包裝 (Check if response is wrapped by SDK)
            data = response.root.model_dump(mode="json", exclude_none=True)
        else:
            data = response.model_dump(mode="json", exclude_none=True)

        json_str = json.dumps(data, indent=2, ensure_ascii=False)  # 將 dict 轉換為漂亮的 JSON 字串 (Convert dict to pretty JSON string)
        syntax = Syntax(json_str, "json", theme="monokai", line_numbers=False)  # 應用語法高亮 (Apply syntax highlighting)
        rprint(syntax)  # 帶顏色列印 (Print it with color)
    except Exception as e:
        # 如果失敗則列印後備文字 (Print fallback text if something fails)
        rprint(f"[red bold]Error printing JSON:[/red bold] {e}")
        rprint(repr(response))

"""
重點摘要:
- **核心概念**: 網站建構代理邏輯。
- **關鍵技術**: Google ADK, LLM Prompting。
- **重要結論**: 透過 Prompt 工程，使 LLM 能夠專注於生成 HTML 程式碼。
"""
