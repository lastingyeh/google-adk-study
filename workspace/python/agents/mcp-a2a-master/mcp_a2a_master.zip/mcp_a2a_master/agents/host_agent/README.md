# 主機代理 (Host Agent)

## 概覽

主機代理 (Host Agent) 是此多代理系統的中樞神經系統。它充當協調者 (orchestrator) 的角色，負責接收任務，將其分解為更小、可管理的步驟，並將這些步驟委派給適當的專業代理。它透過 A2A 發現機制掌握可用代理及其能力，並利用 MCP 伺服器來發現和使用可用的工具。

## 主要職責

*   **任務接收與分解**：主機代理是使用者請求的主要入口點。它分析傳入的任務，並將其分解為可由其他代理執行的動作序列。
*   **代理發現與選擇**：使用 `a2a_discovery` 工具，主機代理動態發現可用的代理及其功能。然後，它根據廣告的能力為每個子任務選擇最合適的代理。
*   **任務委派與協調**：一旦選擇了代理，主機代理就會委派任務並監控其執行。它協調代理之間的資訊流，確保一個代理的輸出可以用作另一個代理的輸入。
*   **工具發現與使用**：主機代理與 MCP 伺服器互動以發現和使用可用的工具。這使其能夠擴展自身能力並提供更複雜的解決方案。

## 如何執行

若要執行主機代理，請從專案根目錄執行以下指令：

```bash
uv run python3 -m agents.host_agent
```

## 與其他元件的互動

*   **A2A 代理**：主機代理使用 A2A 協定與其他代理（例如 `website_builder_simple`）通訊。這使其能夠委派任務並接收結果。
*   **MCP 伺服器**：主機代理連接到 MCP 伺服器以發現和使用工具。這使其能夠存取更廣泛的功能。
*   **CMD 應用程式**：CMD 應用程式提供使用者介面與主機代理互動，允許使用者提交任務並監控其執行。

```mermaid
graph TD
    User[使用者 (User)] --> CMD[CMD 應用程式]
    CMD --> Host[主機代理 (Host Agent)]
    Host <-->|A2A 協定| Agent1[A2A 代理 (e.g., Website Builder)]
    Host <-->|MCP 協定| Server[MCP 伺服器]

    subgraph Discovery [發現機制]
    Host -.-> DiscoveryUtil[A2A/MCP 發現工具]
    end
```

---

## 重點摘要

- **核心概念**：
  <div style='text-align: left;'>
  - 系統的中樞協調者 (Orchestrator)。
  - 負責任務分解、委派與監控。
  </div>
- **關鍵技術**：
  <div style='text-align: left;'>
  - A2A (Agent-to-Agent) 通訊。
  - MCP (Mission Control Protocol) 工具整合。
  - 動態代理發現 (Dynamic Discovery)。
  </div>
- **重要結論**：
  <div style='text-align: left;'>
  - Host Agent 不直接執行所有工作，而是作為管理者，利用其他專用代理和工具來完成複雜任務。
  - 透過動態發現機制，系統具有高度的可擴展性，可以隨時加入新的代理或工具。
  </div>
- **行動項目**：
  <div style='text-align: left;'>
  - 確保在執行 Host Agent 前，相關的 MCP 伺服器與其他 Agent 已啟動或可被發現。
  </div>
