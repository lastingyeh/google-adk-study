# MCP A2A 多代理系統架構設計流程

## 系統整體架構時序圖

```mermaid
sequenceDiagram
    participant User as 使用者
    participant CMD as CMD 應用程式
    participant HostAgent as Host Agent
    participant MCPDiscovery as MCP Discovery
    participant A2ADiscovery as A2A Discovery
    participant MCPConnector as MCP Connector
    participant AgentConnector as Agent Connector
    participant MCPServer as MCP 伺服器
    participant SubAgent as 子代理 (e.g., Website Builder)
    participant LLM as LLM Agent

    Note over User,LLM: 系統初始化階段

    User->>CMD: 啟動 CMD 應用程式
    CMD->>HostAgent: 建立 Host Agent 實例

    HostAgent->>MCPDiscovery: 初始化 MCP Discovery
    MCPDiscovery->>MCPDiscovery: 載入 mcp_config.json
    MCPDiscovery-->>HostAgent: 回傳 MCP 伺服器列表

    HostAgent->>A2ADiscovery: 初始化 A2A Discovery
    A2ADiscovery->>A2ADiscovery: 載入 agent_registry.json
    A2ADiscovery-->>HostAgent: 回傳 A2A 代理基本 URL

    HostAgent->>MCPConnector: 建立 MCP Connector
    MCPConnector->>MCPServer: 連接各 MCP 伺服器
    MCPServer-->>MCPConnector: 回傳可用工具列表
    MCPConnector->>MCPConnector: 快取為 MCPToolsets
    MCPConnector-->>HostAgent: 回傳 MCP 工具集

    HostAgent->>LLM: 建構 LLM Agent
    Note over HostAgent,LLM: 載入 instructions.txt 和 description.txt
    HostAgent->>LLM: 註冊 MCP 工具和 A2A 工具
    LLM-->>HostAgent: Agent 準備就緒

    HostAgent-->>CMD: Host Agent 初始化完成

    Note over User,LLM: 任務執行階段

    User->>CMD: 輸入查詢/任務
    CMD->>HostAgent: invoke(query)

    HostAgent->>LLM: run_async(query)
    LLM->>LLM: 分析查詢內容

    alt 需要發現代理
        LLM->>HostAgent: 呼叫 _list_agents()
        HostAgent->>A2ADiscovery: list_agent_cards()
        A2ADiscovery->>SubAgent: 查詢 /.well-known/agent.json
        SubAgent-->>A2ADiscovery: 回傳 AgentCard
        A2ADiscovery-->>HostAgent: 回傳代理卡片列表
        HostAgent-->>LLM: 回傳可用代理資訊
    end

    alt 需要委派任務給子代理
        LLM->>HostAgent: 呼叫 _delegate_task(agent_name, message)
        HostAgent->>A2ADiscovery: 查找對應的 AgentCard
        A2ADiscovery-->>HostAgent: 回傳目標 AgentCard
        HostAgent->>AgentConnector: 建立 AgentConnector
        AgentConnector->>SubAgent: send_task(message, session_id)
        Note over AgentConnector,SubAgent: 使用 A2A 協定通訊
        SubAgent->>SubAgent: 執行任務
        SubAgent-->>AgentConnector: 回傳執行結果
        AgentConnector-->>HostAgent: 回傳 Task 物件
        HostAgent-->>LLM: 回傳子代理回應
    end

    alt 需要使用 MCP 工具
        LLM->>MCPConnector: 呼叫 MCP 工具
        MCPConnector->>MCPServer: 執行工具指令
        MCPServer-->>MCPConnector: 回傳執行結果
        MCPConnector-->>LLM: 回傳工具結果
    end

    LLM->>LLM: 整合所有結果
    LLM-->>HostAgent: 串流回應事件

    loop 處理回應串流
        HostAgent->>HostAgent: 處理事件
        HostAgent-->>CMD: 回傳更新內容
        CMD-->>User: 顯示回應
    end

    Note over User,LLM: 任務完成
```

## 核心元件互動圖

```mermaid
graph TB
    User[使用者] --> CMD[CMD 應用程式]
    CMD --> HostAgent[Host Agent]

    HostAgent --> MCPDiscovery[MCP Discovery]
    HostAgent --> A2ADiscovery[A2A Discovery]
    HostAgent --> MCPConnector[MCP Connector]
    HostAgent --> AgentConnector[Agent Connector]
    HostAgent --> LLM[LLM Agent]

    MCPDiscovery --> ConfigFile1[mcp_config.json]
    A2ADiscovery --> ConfigFile2[agent_registry.json]

    MCPConnector --> MCPServer1[Streamable HTTP Server]
    MCPConnector --> MCPServer2[Terminal Server]

    AgentConnector --> SubAgent1[Website Builder Agent]
    AgentConnector --> SubAgentN[其他 A2A 代理...]

    LLM --> Instructions[instructions.txt]
    LLM --> Description[description.txt]
```

## 代理發現流程

```mermaid
sequenceDiagram
    participant HostAgent as Host Agent
    participant A2ADiscovery as A2A Discovery
    participant Registry as agent_registry.json
    participant AgentServer as A2A 代理伺服器

    HostAgent->>A2ADiscovery: list_agent_cards()
    A2ADiscovery->>Registry: 讀取代理 URL 列表
    Registry-->>A2ADiscovery: 回傳 base_urls

    loop 針對每個 base_url
        A2ADiscovery->>AgentServer: GET /.well-known/agent.json
        AgentServer-->>A2ADiscovery: 回傳 AgentCard JSON
        A2ADiscovery->>A2ADiscovery: 解析為 AgentCard 物件
    end

    A2ADiscovery-->>HostAgent: 回傳 AgentCard 列表
```

## MCP 工具載入流程

```mermaid
sequenceDiagram
    participant HostAgent as Host Agent
    participant MCPConnector as MCP Connector
    participant MCPDiscovery as MCP Discovery
    participant Config as mcp_config.json
    participant MCPServer as MCP 伺服器

    HostAgent->>MCPConnector: 初始化
    MCPConnector->>MCPDiscovery: list_servers()
    MCPDiscovery->>Config: 讀取設定
    Config-->>MCPDiscovery: mcpServers 設定
    MCPDiscovery-->>MCPConnector: 伺服器定義列表

    loop 針對每個 MCP 伺服器
        alt Streamable HTTP 伺服器
            MCPConnector->>MCPServer: 使用 StreamableHTTPServerParams 連接
        else Stdio 伺服器
            MCPConnector->>MCPServer: 使用 StdioConnectionParams 連接
        end

        MCPServer-->>MCPConnector: 回傳工具定義
        MCPConnector->>MCPConnector: 建立 MCPToolset
    end

    MCPConnector-->>HostAgent: 回傳所有 MCPToolsets
```

## 任務委派流程

```mermaid
sequenceDiagram
    participant User as 使用者
    participant HostAgent as Host Agent
    participant LLM as LLM Agent
    participant AgentConnector as Agent Connector
    participant SubAgent as 子代理

    User->>HostAgent: 提交任務請求
    HostAgent->>LLM: 分析任務
    LLM->>LLM: 決定需要委派給子代理

    LLM->>HostAgent: _delegate_task(agent_name, message)
    HostAgent->>HostAgent: 查找對應的 AgentCard

    HostAgent->>AgentConnector: 建立連接器實例
    AgentConnector->>SubAgent: send_task(message, session_id)

    Note over AgentConnector,SubAgent: 建立 A2A 客戶端連接

    SubAgent->>SubAgent: 執行任務
    SubAgent-->>AgentConnector: 回傳 Task 結果

    AgentConnector-->>HostAgent: 回傳執行結果
    HostAgent->>LLM: 提供子代理回應

    LLM->>LLM: 整合結果
    LLM-->>HostAgent: 生成最終回應
    HostAgent-->>User: 回傳結果
```

## 系統啟動順序

```mermaid
graph TD
    Start[系統啟動] --> InitCMD[初始化 CMD 應用程式]
    InitCMD --> CreateHost[建立 Host Agent]

    CreateHost --> LoadInstructions[載入 instructions.txt]
    CreateHost --> LoadDescription[載入 description.txt]

    CreateHost --> InitMCPDiscovery[初始化 MCP Discovery]
    InitMCPDiscovery --> LoadMCPConfig[載入 mcp_config.json]

    CreateHost --> InitA2ADiscovery[初始化 A2A Discovery]
    InitA2ADiscovery --> LoadAgentRegistry[載入 agent_registry.json]

    LoadMCPConfig --> CreateMCPConnector[建立 MCP Connector]
    CreateMCPConnector --> ConnectMCPServers[連接所有 MCP 伺服器]
    ConnectMCPServers --> LoadMCPTools[載入 MCP 工具]

    LoadAgentRegistry --> ReadyA2A[A2A 發現就緒]

    LoadMCPTools --> BuildLLMAgent[建構 LLM Agent]
    ReadyA2A --> BuildLLMAgent
    LoadInstructions --> BuildLLMAgent
    LoadDescription --> BuildLLMAgent

    BuildLLMAgent --> RegisterTools[註冊所有工具]
    RegisterTools --> Ready[系統就緒]
    Ready --> WaitInput[等待使用者輸入]
```

## 重點摘要

### 核心概念

- **分層架構**: CMD 應用程式 → Host Agent → LLM Agent → MCP/A2A 工具
- **發現機制**: 動態發現 MCP 伺服器和 A2A 代理
- **任務編排**: Host Agent 作為中央協調者,透過 LLM 智慧路由任務
- **協定整合**: 同時支援 MCP 和 A2A 兩種通訊協定

### 關鍵技術

- **MCP (Mission Control Protocol)**: 用於工具和伺服器發現
- **A2A (Agent-to-Agent)**: 用於代理間通訊
- **Google ADK**: LLM Agent 開發框架
- **異步架構**: 全程使用 Python asyncio 處理並發

### 重要結論

1. 系統採用發現-連接-執行的三階段模式
2. Host Agent 負責所有代理和工具的協調
3. 透過設定檔 (JSON) 進行靈活配置
4. 支援可擴展的多代理協作架構

### 行動項目

1. 確保所有設定檔 (mcp_config.json, agent_registry.json) 正確配置
2. 依序啟動 MCP 伺服器、子代理、Host Agent
3. 透過 CMD 應用程式與系統互動
4. 監控各元件間的通訊流程以進行除錯
