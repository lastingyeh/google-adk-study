"""
mcp-a2a-master 的主程式入口點。

這是一個簡單的腳本，用於驗證環境設定是否正確。
它會印出一條歡迎訊息，確認專案已成功執行。

Mermaid 流程圖:
```mermaid
sequenceDiagram
    participant User as 使用者
    participant Main as main.py

    User->>Main: 執行腳本 (Execute Script)
    Main-->>User: 印出 "來自 mcp-a2a-master 的問好！"
```

重點摘要:
- **核心概念**: 專案的進入點 (Entry point)。
- **關鍵技術**: Python 基礎語法。
- **重要結論**: 用於測試環境建置是否成功。
- **行動項目**: 執行此腳本以確認安裝無誤。
"""

def main():
    # 印出歡迎訊息以確認程式正常執行
    # Print welcome message to confirm program execution
    print("來自 mcp-a2a-master 的問好！")


if __name__ == "__main__":
    # 當腳本被直接執行時呼叫 main 函式
    # Call main function when script is executed directly
    main()
