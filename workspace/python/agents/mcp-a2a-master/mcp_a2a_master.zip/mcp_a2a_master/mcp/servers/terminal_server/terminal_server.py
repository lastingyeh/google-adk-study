from mcp.server.fastmcp import FastMCP
import os
import subprocess

mcp = FastMCP("terminal_server")
DEFAULT_WORKSPACE = os.path.expanduser("~/mcp/workspace")

@mcp.tool("terminal_server")
async def run_command(command:str) -> str:
    """
    在終端機中執行指令並回傳輸出。
    Run a command in the terminal and return the output.

    Args:
        command (str): 要在終端機中執行的指令。 (The command to run in the terminal.)

    Returns:
        str: 指令的輸出，如果指令失敗則回傳錯誤訊息。 (The output of the command or an error message if the command fails.)
    """
    try:
        result = subprocess.run(command, shell=True, cwd=DEFAULT_WORKSPACE, text=True, capture_output=True)
        return result.stdout or result.stderr
    except Exception as e:
        return f"執行指令時發生錯誤 (Error running command): {str(e)}"

if __name__ == "__main__":
    mcp.run(transport="stdio")

"""
重點摘要:
- **核心概念**: MCP Stdio Server 範例。
- **關鍵技術**: `FastMCP`, `subprocess` (執行系統指令), Stdio Transport。
- **重要結論**: 實作了一個可以在伺服器端執行 Shell 指令的工具，這是一個強大但也潛在危險的功能，需謹慎使用。
"""
