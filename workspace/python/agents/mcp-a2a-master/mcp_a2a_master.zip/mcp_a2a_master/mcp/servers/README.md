# MCP 伺服器 (MCP Servers)

## 概覽

此目錄包含多代理系統中使用的任務控制協定 (Mission Control Protocol, MCP) 伺服器的實作。MCP 伺服器負責提供標準化方式，讓代理發現並與工具及其他資源進行互動。

## 伺服器實作

### 可串流 HTTP 伺服器 (`streamable_http_server.py`)

此伺服器提供用於即時、非同步通訊的可串流 HTTP 介面。它非常適合需要連續資料流的應用程式，例如串流日誌或即時通知。

**如何執行：**

```bash
uv run python3 -m mcp.servers.streamable_http_server
```

### 終端機伺服器 (`terminal_server/terminal_server.py`)

此伺服器提供使用標準輸入/輸出 (stdio) 的簡單直接通訊通道。它非常適合需要簡單、不花哨的通訊機制的場景。

## 與其他元件的互動

*   **代理 (Agents)**：代理連接到這些 MCP 伺服器以發現並使用它們提供的工具和資源。伺服器充當代理與底層工具之間的橋樑。
*   **MCP 工具 (MCP Utilities)**：`mcp_discovery` 工具被代理用來尋找並連接到這些伺服器。

---

## 重點摘要

- **核心概念**：
  <div style='text-align: left;'>
  - MCP Server 實作。
  - 資源與工具的提供者。
  </div>
- **關鍵技術**：
  <div style='text-align: left;'>
  - FastMCP。
  - HTTP Server-Sent Events (SSE) (Streamable HTTP)。
  - Standard IO (Stdio)。
  </div>
- **重要結論**：
  <div style='text-align: left;'>
  - 提供了兩種不同的傳輸方式 (Transport) 來適應不同的使用場景。
  - `streamable_http_server` 展示了如何透過 MCP 暴露算術運算工具。
  - `terminal_server` 展示了如何透過 MCP 暴露系統指令執行能力。
  </div>
- **行動項目**：
  <div style='text-align: left;'>
  - 確保在執行 Agent 前先啟動需要的 MCP Server。
  </div>
