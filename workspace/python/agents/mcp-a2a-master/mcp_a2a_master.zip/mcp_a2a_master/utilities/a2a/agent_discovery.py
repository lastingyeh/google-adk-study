import json
import os
from a2a.types import (
    AgentCard
)

from a2a.client import A2ACardResolver, A2AClient

import httpx

class AgentDiscovery:
    """
    透過讀取 URL 的註冊檔並查詢每一個 URL 的 /.well-known/agent.json 端點來檢索 AgentCard，
    藉此發現 A2A 代理。
    Discovers A2A Agents by reading a registry file of URLs and
    querying each one's /.well-known/agent.json endpoint to retrieve
    an AgentCard

    Attributes:
        registry_file (str): 代理註冊檔案的路徑。 (Path to the agent registry file.)
        base_urls (List[str]): A2A 代理的基本 URL 列表。 (List of base URLs for A2A Agents.)
    """

    def __init__(self, registry_file: str = None):
        """
        初始化 AgentDiscovery。
        Initialise the AgentDiscovery

        Args:
            registry_file (str): 代理註冊檔案的路徑。 (Path to the agent registry file.)
                預設為 'utilities/a2a/agent_registry.json'。 (Defaults to 'utilities/a2a/agent_registry.json'.)
        """

        if registry_file:
            self.registry_file = registry_file
        else:
            self.registry_file = os.path.join(
                os.path.dirname(__file__),
                'agent_registry.json'
            )
        self.base_urls = self._load_registry()

    def _load_registry(self) -> list[str]:
        """
        載入並解析註冊 JSON 檔案為 URL 列表。
        Load and parse the registry JSON file into a list of URLs

        Returns:
            list[str]: A2A 代理的基本 URL 列表。 (List of base URLs for A2A Agents.)
        """
        try:
            with open(self.registry_file, 'r') as f:
                data = json.load(f)
            if not isinstance(data, list):
                raise ValueError("註冊檔必須包含 URL 列表。 (Registry file must contain a list of URLs.)")
            return data
        except FileNotFoundError:
            print(f"找不到註冊檔 (Registry file) '{self.registry_file}'。")
            return []
        except (json.JSONDecodeError, ValueError) as e:
            print(f"解析註冊檔時發生錯誤 (Error parsing registry file): {e}")
            return []

    async def list_agent_cards(self) -> list[AgentCard]:
        """
        非同步地從註冊表中的每個基本 URL 獲取 AgentCard。
        Asynchronously fetches AgentCards from each
        base URL in the registry.

        Returns:
            list[AgentCard]: 從代理檢索到的 AgentCard 列表。 (List of AgentCards retrieved from the agents.)


        """
        cards: list[AgentCard] = []

        async with httpx.AsyncClient(timeout=300.0) as httpx_client:

            for base_url in self.base_urls:
                resolver = A2ACardResolver(
                    base_url=base_url.rstrip('/'),
                    httpx_client=httpx_client
                )

                card = await resolver.get_agent_card()

                cards.append(card)

        return cards

"""
重點摘要:
- **核心概念**: A2A 代理發現 (Discovery)。
- **關鍵技術**: JSON 設定檔, HTTP 請求, A2A Protocol (/.well-known/agent.json)。
- **重要結論**: 實作了一個簡單的基於檔案的發現機制，用於定位網路上的其他 Agent。
"""
