# MCP A2A 多代理系統完整學習流程

本文件提供從零開始建構 MCP A2A 多代理系統的完整學習流程，適合逐步理解和實作整個架構。

---

## 第一階段：環境準備與基礎設定

### 第一步：專案初始化

1. 建立專案目錄結構
2. 建立 `pyproject.toml` 配置檔案
   - 定義專案名稱、版本、描述
   - 設定 Python 版本需求 (>=3.11)
   - 列出核心依賴套件：
     - `a2a-sdk>=0.2.15` (A2A 通訊協定)
     - `mcp[cli]>=1.12.0` (MCP 協定)
     - `google-adk>=1.7.0` (Google Agent Development Kit)
     - `asyncclick>=8.1.8` (非同步命令列介面)

### 第二步：安裝依賴套件

```bash
# 建立虛擬環境
python3 -m venv .venv
source .venv/bin/activate

# 安裝依賴
uv pip install -r requirements.txt
```

### 第三步：建立主程式入口

建立 `main.py`：

- 簡單的 Hello World 程式
- 驗證環境設定是否正確
- 測試執行：`uv run python3 main.py`

---

## 第二階段：建立共用工具模組

### 第四步：建立檔案載入工具

建立 `utilities/common/file_loader.py`：

- 實作 `load_instructions_file()` 函式
- 用於載入代理的指令檔案和描述檔案
- 支援讀取純文字配置檔案

### 第五步：建立 MCP 發現機制

建立 `utilities/mcp/mcp_discovery.py`：

- 建立 `MCPDiscovery` 類別
- 實作 `_load_config()` 方法讀取 MCP 配置檔案
- 實作 `list_servers()` 方法列出所有可用的 MCP 伺服器

### 第六步：建立 MCP 配置檔案

建立 `utilities/mcp/mcp_config.json`：

```json
{
  "mcpServers": {
    "terminal_server": {
      "command": "uv",
      "args": ["--directory", "路徑", "run", "terminal_server.py"]
    },
    "arithmetic_server": {
      "command": "streamable_http",
      "args": ["http://localhost:3000/mcp/"]
    }
  }
}
```

### 第七步：建立 MCP 連接器

建立 `utilities/mcp/mcp_connect.py`：

- 建立 `MCPConnector` 類別
- 實作 `_load_all_tools()` 方法載入 MCP 工具
- 支援兩種連接模式：
  - Stdio 連接 (標準輸入輸出)
  - Streamable HTTP 連接
- 實作 `get_tools()` 方法回傳可用工具列表

### 第八步：建立 A2A 發現機制

建立 `utilities/a2a/agent_discovery.py`：

- 建立 `AgentDiscovery` 類別
- 實作 `_load_registry()` 載入代理註冊檔案
- 實作 `list_agent_cards()` 查詢代理的 `/.well-known/agent.json` 端點
- 回傳 `AgentCard` 物件列表

### 第九步：建立 A2A 代理註冊檔案

建立 `utilities/a2a/agent_registry.json`：

```json
["http://localhost:10000"]
```

### 第十步：建立 A2A 連接器

建立 `utilities/a2a/agent_connect.py`：

- 建立 `AgentConnector` 類別
- 實作 `send_task()` 方法發送任務給指定代理
- 處理 A2A 客戶端連接和通訊
- 支援串流回應處理

---

## 第三階段：建立 MCP 伺服器

### 第十一步：建立可串流 HTTP 伺服器

建立 `mcp/servers/streamable_http_server.py`：

- 使用 `FastMCP` 框架建立 HTTP 伺服器
- 定義 Pydantic 資料模型 (Input/Output)
- 實作範例工具 (如 `add_numbers`)
- 設定伺服器監聽 `localhost:3000`
- 使用 `streamable-http` 傳輸模式

測試指令：

```bash
uv run python3 -m mcp.servers.streamable_http_server
```

### 第十二步：建立 Stdio 伺服器 (選用)

建立 `mcp/servers/terminal_server/terminal_server.py`：

- 建立基於 Stdio 的 MCP 伺服器
- 實作終端機相關工具
- 使用標準輸入輸出進行通訊

---

## 第四階段：建立專用代理

### 第十三步：建立網站建構代理指令檔

建立 `agents/website_builder_simple/instructions.txt`：

```
你是一位專業的 AI 網頁開發人員。你的工作是根據描述簡單網站的使用者查詢，生成一個包含 HTML、CSS 和 JavaScript 的完整 HTML 檔案。
整個內容應包裹在有效的 HTML5 結構中。
設計應簡潔現代。避免使用框架。將所有內容保持在單一檔案中。
僅回傳完整的 HTML 內容字串。
```

### 第十四步：建立網站建構代理描述檔

建立 `agents/website_builder_simple/description.txt`：

```
一個簡易的網站建構代理，可以建立基本的網頁。
```

### 第十五步：實作網站建構代理核心

建立 `agents/website_builder_simple/agent.py`：

- 建立 `WebsiteBuilderSimple` 類別
- 載入 instructions 和 description
- 使用 Google ADK 的 `LlmAgent` 建立代理
- 實作 `invoke()` 方法處理查詢
- 設定記憶體、會話和工件服務 (InMemory)

### 第十六步：建立網站建構代理執行器

建立 `agents/website_builder_simple/agent_executor.py`：

- 建立 A2A 伺服器實例
- 註冊 `WebsiteBuilderSimple` 代理
- 設定監聽端口 (如 10000)
- 實作啟動邏輯

### 第十七步：建立網站建構代理主程式

建立 `agents/website_builder_simple/__main__.py`：

- 從 `agent_executor.py` 匯入主函式
- 執行代理伺服器

測試指令：

```bash
uv run python3 -m agents.website_builder_simple
```

---

## 第五階段：建立主機代理 (核心協調者)

### 第十八步：建立主機代理指令檔

建立 `agents/host_agent/instructions.txt`：

```
你是一個協調者，擁有兩類工具：
1) A2A 代理工具：_list_agents(), _delegate_task(agent_name, message)
2) MCP 工具：每個工具名稱對應一個 FunctionTool

請根據工具名稱準確選擇合適的工具，並使用正確的參數進行呼叫。請勿產生幻覺 (hallucinate)。
```

### 第十九步：建立主機代理描述檔

建立 `agents/host_agent/description.txt`：

```
主機代理負責協調多個代理和工具，將任務路由至適當的處理者。
```

### 第二十步：實作主機代理核心邏輯

建立 `agents/host_agent/agent.py`：

- 建立 `HostAgent` 類別
- **初始化階段**：
  - 載入 instructions 和 description
  - 初始化 `AgentDiscovery` 和 `MCPConnector`
  - 發現並載入所有 A2A 代理
  - 發現並載入所有 MCP 工具
- **建立內部工具**：
  - `_list_agents()`: 列出所有可用代理
  - `_delegate_task()`: 委派任務給指定代理
- **建立 LlmAgent**：
  - 結合 A2A 工具和 MCP 工具
  - 配置系統指令
- **實作 invoke() 方法**：
  - 接收使用者查詢
  - 串流處理回應事件
  - 解析任務完成狀態

### 第二十一步：建立主機代理執行器

建立 `agents/host_agent/agent_executor.py`：

- 建立 A2A 伺服器實例
- 註冊 `HostAgent` 代理
- 設定監聽端口 (如 10001)
- 實作啟動邏輯

### 第二十二步：建立主機代理主程式

建立 `agents/host_agent/__main__.py`：

- 從 `agent_executor.py` 匯入主函式
- 執行代理伺服器

測試指令：

```bash
uv run python3 -m agents.host_agent
```

---

## 第六階段：建立命令列介面

### 第二十三步：實作 CLI 核心

建立 `app/cmd/cmd.py`：

- 使用 `asyncclick` 建立非同步 CLI
- 定義命令列選項：
  - `--agent`: A2A 代理伺服器的 URL (預設: http://127.0.0.1:10001)
  - `--session`: 工作階段 ID (0 表示新會話)
- **主要流程**：
  1. 使用 `A2ACardResolver` 取得代理卡片
  2. 建立 `AgentConnector` 連接代理
  3. 進入互動迴圈：
     - 讀取使用者輸入
     - 使用 `send_task()` 發送訊息
     - 串流顯示回應

### 第二十四步：建立 CLI 主程式

建立 `app/cmd/__main__.py`：

- 從 `cmd.py` 匯入 CLI 函式
- 執行非同步主程式

測試指令：

```bash
uv run python3 -m app.cmd.cmd
```

### 第二十五步：建立目錄樹工具 (選用)

建立 `app/cmd/tree.py`：

- 實作專案目錄結構視覺化工具
- 用於顯示專案檔案架構

---

## 第七階段：系統整合與測試

### 第二十六步：啟動完整系統

按照以下順序啟動各組件：

1. **啟動 MCP 伺服器** (終端機 1)：

```bash
uv run python3 -m mcp.servers.streamable_http_server
```

2. **啟動網站建構代理** (終端機 2)：

```bash
uv run python3 -m agents.website_builder_simple
```

3. **啟動主機代理** (終端機 3)：

```bash
uv run python3 -m agents.host_agent
```

4. **啟動 CLI 介面** (終端機 4)：

```bash
uv run python3 -m app.cmd.cmd
```

### 第二十七步：測試基本功能

在 CLI 中測試以下場景：

1. **測試 MCP 工具**：

```
使用者: 計算 5 + 3
系統: 呼叫 arithmetic_server 的 add_numbers 工具
```

2. **測試 A2A 代理委派**：

```
使用者: 建立一個簡單的個人部落格網頁
系統: 主機代理將任務委派給 website_builder_simple 代理
```

3. **測試代理發現**：

```
使用者: 列出所有可用的代理
系統: 顯示已註冊的代理列表
```

### 第二十八步：驗證系統架構

確認以下流程正常運作：

1. **發現機制**：

   - MCP Discovery 正確讀取 `mcp_config.json`
   - A2A Discovery 正確讀取 `agent_registry.json`
   - 成功取得代理卡片 (AgentCard)

2. **通訊流程**：

   - CLI → HostAgent → WebsiteBuilderSimple
   - HostAgent → MCP Tools

3. **資料流**：
   - 使用者輸入 → 任務分析 → 工具/代理選擇 → 執行 → 回應

---

## 第八階段：擴展與優化

### 第二十九步：新增自訂 MCP 伺服器

學習如何建立新的 MCP 伺服器：

1. 在 `mcp/servers/` 建立新資料夾
2. 定義輸入/輸出 Pydantic 模型
3. 使用 `@mcp.tool()` 裝飾器註冊工具
4. 在 `mcp_config.json` 註冊伺服器

### 第三十步：新增自訂 A2A 代理

學習如何建立新的專用代理：

1. 在 `agents/` 建立新資料夾
2. 撰寫 `instructions.txt` 和 `description.txt`
3. 實作 `agent.py` (繼承或參考現有模式)
4. 建立 `agent_executor.py` 和 `__main__.py`
5. 在 `agent_registry.json` 註冊代理

### 第三十一步：優化錯誤處理

改進系統穩健性：

- 新增 try-catch 錯誤處理
- 實作優雅關閉機制 (signal handling)
- 新增日誌記錄 (logging)
- 設定逾時處理

### 第三十二步：效能優化

提升系統效能：

- 實作工具快取機制
- 優化非同步操作
- 減少不必要的網路請求
- 使用連接池管理

---

## 系統架構總覽

```mermaid
graph TB
    User[使用者 CLI]

    subgraph "主機層"
        HostAgent[Host Agent<br/>協調者]
    end

    subgraph "發現層"
        MCPDiscovery[MCP Discovery]
        A2ADiscovery[A2A Discovery]
        MCPConfig[mcp_config.json]
        A2ARegistry[agent_registry.json]
    end

    subgraph "連接層"
        MCPConnector[MCP Connector]
        A2AConnector[A2A Connector]
    end

    subgraph "執行層"
        MCPServer[MCP Servers<br/>streamable_http_server]
        A2AAgent[A2A Agents<br/>website_builder_simple]
    end

    subgraph "工具層"
        FileLoader[File Loader]
        LlmAgent[Google ADK LlmAgent]
    end

    User -->|查詢| HostAgent
    HostAgent -->|發現| MCPDiscovery
    HostAgent -->|發現| A2ADiscovery
    MCPDiscovery -->|讀取| MCPConfig
    A2ADiscovery -->|讀取| A2ARegistry
    HostAgent -->|連接| MCPConnector
    HostAgent -->|連接| A2AConnector
    MCPConnector -->|呼叫工具| MCPServer
    A2AConnector -->|委派任務| A2AAgent
    HostAgent -->|使用| LlmAgent
    A2AAgent -->|使用| LlmAgent
    HostAgent -->|載入指令| FileLoader
    A2AAgent -->|載入指令| FileLoader
```

---

## 學習檢查清單

### 基礎概念理解

- [ ] 理解 MCP (Mission Control Protocol) 協定的作用
- [ ] 理解 A2A (Agent-to-Agent) 通訊機制
- [ ] 理解多代理系統的架構模式
- [ ] 理解主機代理 (Host Agent) 的協調角色

### 技術實作能力

- [ ] 能夠建立和配置 MCP 伺服器
- [ ] 能夠建立和部署 A2A 代理
- [ ] 能夠實作代理發現機制
- [ ] 能夠整合 Google ADK 框架

### 系統整合技能

- [ ] 能夠配置 JSON 設定檔
- [ ] 能夠處理非同步通訊
- [ ] 能夠實作工具註冊和呼叫
- [ ] 能夠建立 CLI 互動介面

### 除錯與優化

- [ ] 能夠診斷連接問題
- [ ] 能夠追蹤任務委派流程
- [ ] 能夠優化系統效能
- [ ] 能夠擴展系統功能

---

## 常見問題與解決方案

### Q1: MCP 伺服器無法連接

**檢查項目**：

- 確認伺服器已啟動且端口正確
- 檢查 `mcp_config.json` 中的 URL 和參數
- 確認防火牆設定允許連接

### Q2: A2A 代理無法發現

**檢查項目**：

- 確認代理伺服器已啟動
- 檢查 `agent_registry.json` 中的 URL
- 確認 `/.well-known/agent.json` 端點可訪問

### Q3: 任務委派失敗

**檢查項目**：

- 確認目標代理已正確註冊
- 檢查 HostAgent 的 instructions 是否正確
- 查看日誌確認錯誤訊息

### Q4: 工具呼叫返回錯誤

**檢查項目**：

- 確認參數格式符合 Pydantic 模型定義
- 檢查 MCP 工具是否正確載入
- 驗證輸入資料的型別和範圍

---

## 進階學習方向

1. **深入 MCP 協定**：

   - 研究 MCP 規範文件
   - 實作更複雜的 MCP 工具
   - 探索不同的傳輸模式

2. **優化 A2A 通訊**：

   - 實作代理間的狀態同步
   - 建立代理能力協商機制
   - 實作分散式任務處理

3. **整合外部服務**：

   - 連接資料庫
   - 整合第三方 API
   - 實作檔案系統操作

4. **安全性強化**：

   - 實作身份驗證機制
   - 新增授權檢查
   - 加密敏感資料傳輸

5. **監控與可觀測性**：
   - 新增效能監控
   - 實作分散式追蹤
   - 建立健康檢查端點

---

## 總結

本學習流程從環境設定開始，逐步建構完整的 MCP A2A 多代理系統。關鍵步驟包括：

1. **第一階段**：建立專案基礎和依賴管理
2. **第二階段**：實作發現和連接機制
3. **第三階段**：建立 MCP 伺服器提供工具
4. **第四階段**：建立專用代理處理特定任務
5. **第五階段**：建立主機代理進行協調
6. **第六階段**：建立使用者互動介面
7. **第七階段**：整合測試和驗證
8. **第八階段**：擴展和優化系統

透過完成這 32 個步驟，您將掌握建構可擴展、模組化的多代理系統所需的核心技能。
